upload these as different "orientations" in 3 colors.

make one of the reds be the default pls 