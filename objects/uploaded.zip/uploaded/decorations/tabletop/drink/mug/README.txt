0: down
1: right
2: up
3: left

-- 

red: #ac3232
pink: #fad2dc
tan: #eec39a
whitegrey: #9badb7
