1x3 is default (down)
1x2 is `right`