TYPE: embedded image

interaction distance: 1
image / preview image: "temporary poster.png"

"Press x to view poster" 