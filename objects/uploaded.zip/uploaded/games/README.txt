for arcade games, set the activation distance to 0.

tags:
decoration, decoration/entertainment, game