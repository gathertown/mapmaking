should each be their own object, with appropriate 
- interaction type
- activated image

should also have the tag
- wayfinding