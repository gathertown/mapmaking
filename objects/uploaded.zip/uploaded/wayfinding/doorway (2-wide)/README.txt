each of these are color variants of each other

call it "Doorway (2-wide)"

also tag tag with
- door
- social
- conference
- education
- office