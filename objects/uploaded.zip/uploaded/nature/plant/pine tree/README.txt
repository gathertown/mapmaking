
forest: #5f9234
tan:    #d9a066
teal:   #37946e