0 = down
1 = right